package demo.solution.DatabaseSQL;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    public static final String dbname="signup.db";
    public Database(Context context){
        super(context,dbname,null,1);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create table users (_id integer primary key autoincrement, name text, username text, password text)";
        db.execSQL(query);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
        onCreate(db);
    }

    public boolean insertData(String name, String username,String password){
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        contentValues.put("username",username);
        contentValues.put("password",password);


        long r=sqLiteDatabase.insert("users",null,contentValues);
        return r != -1;
    }
    public Cursor getInfo(){
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        return sqLiteDatabase.rawQuery("select * from users",null);
    }
    public boolean deleteData(String username){
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        @SuppressLint("Recycle")
        Cursor cursor= sqLiteDatabase.rawQuery("select * from users where username=? ",new String[]{username});
        if (cursor.getCount()>0){
            long r=sqLiteDatabase.delete("users","username=?",new String[]{username});
            return r != -1;
        }
        return false;
    }

    public boolean updateData(String name,String password,String username){
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        contentValues.put("password",password);

        @SuppressLint("Recycle")
        Cursor cursor=sqLiteDatabase.rawQuery("select * from users where username=?",new String[]{username});
        if(cursor.getCount()>0){
            long r=sqLiteDatabase.delete("users","username=?",new String[]{username});
            return r != -1;
        }
        return  false;
    }
}
