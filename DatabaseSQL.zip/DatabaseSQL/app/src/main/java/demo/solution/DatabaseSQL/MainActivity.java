package demo.solution.DatabaseSQL;


import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;

import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    Database database;
    Button BtnInsert , BtnUpdate,BtnDelete,BtnView;
    TextInputEditText EditName,EditUsername,EditPassword;
    Cursor cursor;
    StringBuffer stringBuffer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        BtnInsert=findViewById(R.id.btn_insert);
        BtnDelete=findViewById(R.id.btn_delete);
        BtnUpdate=findViewById(R.id.btn_update);
        BtnView=findViewById(R.id.btn_view);

        EditName=findViewById(R.id.EditName);
        EditUsername=findViewById(R.id.EditUsername);
        EditPassword = findViewById(R.id.EditPassword);

         database=new Database(this);




        //BtnInsert
        clickInsertBtn();

        //BtnDelete
        clickDeleteBtn();

        //BtnUpdate
        clickUpdateBtn();

        //BtnView
        clickViewBtn();
    }

    private void clickInsertBtn() {
        BtnInsert.setOnClickListener(v -> {
            String name = Objects.requireNonNull(EditName.getText()).toString();
            String username= Objects.requireNonNull(EditUsername.getText()).toString();
            String password= Objects.requireNonNull(EditPassword.getText()).toString();
            if(name.isEmpty() || username.isEmpty() || password.isEmpty()){
                Toast.makeText(MainActivity.this, "All field are required", Toast.LENGTH_SHORT).show();
            }
            else {
                boolean i=database.insertData(name, username, password);
                if(i){
                    Toast.makeText(MainActivity.this, "Successfully inserted ", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(this, "failed !", Toast.LENGTH_SHORT).show();
                }
            }
            EditName.setText("");
            EditUsername.setText("");
            EditPassword.setText("");

        });
    }


    public void clickDeleteBtn() {
        BtnDelete.setOnClickListener(v -> {
            String username= Objects.requireNonNull(EditUsername.getText()).toString();
            boolean i=database.deleteData(username);
            if(i){
                Toast.makeText(MainActivity.this, "Deleted Successfully ", Toast.LENGTH_SHORT).show();
            }else Toast.makeText(this, " Note Successfully", Toast.LENGTH_SHORT).show();

        });
    }

    public void clickViewBtn() {
        BtnView.setOnClickListener(v -> {
            cursor = database.getInfo();
            if(cursor.getCount()==0){
                Toast.makeText(MainActivity.this,"No found data",Toast.LENGTH_SHORT).show();
            }
            stringBuffer=new StringBuffer();
            while (cursor.moveToNext()){
                stringBuffer.append("Name : ").append(cursor.getString(1)).append("\n");
                stringBuffer.append("Username : ").append(cursor.getString(2)).append("\n");
                stringBuffer.append("Password : ").append(cursor.getString(3)).append("\n\n");
            }
            //alertfunction
            alertShowDialogFunctioMethod(MainActivity.this, stringBuffer,"Sign up user data");
        });
    }

    public static void alertShowDialogFunctioMethod(MainActivity mainActivity, StringBuffer stringBuffer, String signUpUserData) {
        AlertDialog.Builder builder=new AlertDialog.Builder(mainActivity);
        builder.setCancelable(true);
        builder.setTitle(signUpUserData);
        builder.setMessage(stringBuffer.toString());
        builder.show();
    }


    public void clickUpdateBtn() {
        BtnUpdate.setOnClickListener(v -> {
            String name = Objects.requireNonNull(EditName.getText()).toString();
            String username= Objects.requireNonNull(EditUsername.getText()).toString();
            String password= Objects.requireNonNull(EditPassword.getText()).toString();

            boolean i=database.updateData(name,password,username);
            if(i){
                Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show();
            }else Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
        });
    }
}